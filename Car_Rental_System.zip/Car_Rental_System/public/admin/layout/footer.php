    </div><!-- .admin-main-content -->
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
    var toggle = document.getElementById('sidebarToggle');
    var sidebar = document.getElementById('adminSidebar');
    var backdrop = document.getElementById('adminSidebarBackdrop');
    function setSidebarOpen(open) {
        if (sidebar) sidebar.classList.toggle('show', open);
        if (backdrop) backdrop.classList.toggle('show', open);
    }
    if (toggle && sidebar) {
        toggle.addEventListener('click', function(){
            setSidebarOpen(!sidebar.classList.contains('show'));
        });
    }
    if (backdrop) {
        backdrop.addEventListener('click', function(){ setSidebarOpen(false); });
    }
    var search = document.getElementById('adminGlobalSearch');
    if (search) {
        search.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                var q = this.value.trim();
                var base = document.querySelector('meta[name="admin-base"]');
                var url = (base && base.getAttribute('content')) || '';
                if (q) window.location = url + '/admin/bookings.php?search=' + encodeURIComponent(q);
                else window.location = url + '/admin/bookings.php';
            }
        });
    }
    if (sidebar) {
        var navLinks = sidebar.querySelectorAll('a.nav-link');
        navLinks.forEach(function(link){
            link.addEventListener('click', function(){
                if (window.innerWidth <= 991) setSidebarOpen(false);
            });
        });
    }
})();
</script>
<?php $adminFooterBase = \App\Helpers::baseUrl(); ?>
<script src="<?= \App\Helpers::e($adminFooterBase) ?>/assets/password-toggle.js"></script>
</body>
</html>
