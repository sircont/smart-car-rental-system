<?php
$pageTitle = $pageTitle ?? 'Admin';
$base = \App\Helpers::baseUrl();
$current = basename($_SERVER['PHP_SELF'], '.php');
if ($current === 'index') $current = 'dashboard';
$branchesNavActive = in_array($current, ['branches', 'branch-edit'], true);
$user = \App\Auth::user();
$userName = $user ? \App\Helpers::e($user['name']) : 'Admin';
$userInitial = $userName ? mb_substr($userName, 0, 1) : 'A';
$adminCssVersion = @filemtime(__DIR__ . '/../assets/admin.css') ?: time();
?>
<!DOCTYPE html>
<html lang="en" class="admin-layout">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="admin-base" content="<?= \App\Helpers::e($base) ?>">
    <title><?= \App\Helpers::e($pageTitle) ?> |DriveSmart Rentals</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= $base ?>/admin/assets/admin.css?v=<?= (int)$adminCssVersion ?>" rel="stylesheet">
</head>
<body class="admin-dark">
<!-- Mobile top bar -->
<div class="admin-mobile-bar">
    <button type="button" class="btn btn-admin-outline border-0" id="sidebarToggle" aria-label="Menu"><i class="bi bi-list fs-4"></i></button>
    <span class="ms-2 fw-600">DriveSmart Rentals</span>
</div>

<aside class="admin-sidebar" id="adminSidebar">
    <div class="brand">DriveSmart Rentals</div>
    <a class="admin-sidebar-site-link" href="<?= $base ?>/index.php"><i class="bi bi-house me-2"></i> Site</a>
    <div class="search-wrap">
        <i class="bi bi-search"></i>
        <input type="text" placeholder="Search here..." aria-label="Search">
    </div>
    <div class="admin-sidebar-scroll">
    <nav class="nav flex-column">
        <a class="nav-link <?= $current === 'dashboard' ? 'active' : '' ?>" href="<?= $base ?>/admin/"><i class="bi bi-speedometer2"></i> Dashboard</a>
        <a class="nav-link <?= $current === 'vehicles' ? 'active' : '' ?>" href="<?= $base ?>/admin/vehicles.php"><i class="bi bi-car-front"></i> Vehicles</a>
        <a class="nav-link <?= $current === 'bookings' ? 'active' : '' ?>" href="<?= $base ?>/admin/bookings.php"><i class="bi bi-calendar-check"></i> Bookings</a>
        <a class="nav-link <?= $current === 'brands' ? 'active' : '' ?>" href="<?= $base ?>/admin/brands.php"><i class="bi bi-tags"></i> Brands</a>
        <a class="nav-link <?= $branchesNavActive ? 'active' : '' ?>" href="<?= $base ?>/admin/branches.php"><i class="bi bi-geo-alt"></i> Branches</a>
        <a class="nav-link <?= $current === 'maintenance' ? 'active' : '' ?>" href="<?= $base ?>/admin/maintenance.php"><i class="bi bi-wrench"></i> Maintenance</a>
        <a class="nav-link <?= $current === 'users' ? 'active' : '' ?>" href="<?= $base ?>/admin/users.php"><i class="bi bi-people"></i> Users</a>
        <a class="nav-link <?= $current === 'staff' ? 'active' : '' ?>" href="<?= $base ?>/admin/staff.php"><i class="bi bi-person-badge"></i> Staff</a>
        <a class="nav-link <?= $current === 'payments' ? 'active' : '' ?>" href="<?= $base ?>/admin/payments.php"><i class="bi bi-credit-card"></i> Payments</a>
        <a class="nav-link <?= $current === 'insurance' ? 'active' : '' ?>" href="<?= $base ?>/admin/insurance.php"><i class="bi bi-shield-check"></i> Insurance</a>
        <a class="nav-link <?= $current === 'discounts' ? 'active' : '' ?>" href="<?= $base ?>/admin/discounts.php"><i class="bi bi-percent"></i> Discounts</a>
        <a class="nav-link <?= $current === 'contacts' ? 'active' : '' ?>" href="<?= $base ?>/admin/contacts.php"><i class="bi bi-envelope"></i> Contact</a>
        <a class="nav-link <?= $current === 'activity' ? 'active' : '' ?>" href="<?= $base ?>/admin/activity.php"><i class="bi bi-journal-text"></i> Activity</a>
        <a class="nav-link <?= $current === 'reports' ? 'active' : '' ?>" href="<?= $base ?>/admin/reports.php"><i class="bi bi-file-earmark-bar-graph"></i> Report</a>
        <a class="nav-link <?= $current === 'testimonials' ? 'active' : '' ?>" href="<?= $base ?>/admin/testimonials.php"><i class="bi bi-chat-quote"></i> Testimonials</a>
    </nav>
    </div>
</aside>
<div class="admin-sidebar-backdrop" id="adminSidebarBackdrop" aria-hidden="true"></div>

<main class="admin-main">
    <header class="admin-main-header">
        <div class="admin-main-header-search">
            <i class="bi bi-search"></i>
            <input type="text" placeholder="Search here..." aria-label="Search" id="adminGlobalSearch">
        </div>
        <div class="admin-main-header-user dropstart">
            <button class="dropdown-toggle" type="button" id="adminMainProfileMenu" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="user-avatar"><?= \App\Helpers::e($userInitial) ?></div>
                <div class="user-info text-start">
                    <div class="name"><?= $userName ?></div>
                    <div class="role">Admin</div>
                </div>
                <i class="bi bi-chevron-down text-muted ms-2" style="font-size:0.8rem;"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="adminMainProfileMenu">
                <li><span class="dropdown-item-text small text-muted"><?= $user ? \App\Helpers::e($user['email']) : '' ?></span></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="<?= $base ?>/profile.php"><i class="bi bi-person me-2"></i>Profile</a></li>
                <li><a class="dropdown-item" href="<?= $base ?>/change-password.php"><i class="bi bi-key me-2"></i>Change password</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="<?= $base ?>/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
            </ul>
        </div>
    </header>
    <div class="admin-main-content">
