<?php
require_once dirname(dirname(__DIR__)) . '/bootstrap.php';

use App\Auth;
use App\Database;
use App\Helpers;
use App\Notification;

Auth::requireAdmin();
$adminAlerts = Notification::getUnreadForAdmin();

$stats = [
    'vehicles' => (int) Database::run('SELECT COUNT(*) FROM vehicles')->fetchColumn(),
    'available' => (int) Database::run('SELECT COUNT(*) FROM vehicles WHERE is_available = 1')->fetchColumn(),
    'unavailable' => (int) Database::run('SELECT COUNT(*) FROM vehicles WHERE is_available = 0')->fetchColumn(),
    'bookings' => (int) Database::run('SELECT COUNT(*) FROM bookings')->fetchColumn(),
    'pending_bookings' => (int) Database::run('SELECT COUNT(*) FROM bookings WHERE booking_status = ?', ['pending'])->fetchColumn(),
    'brands' => (int) Database::run('SELECT COUNT(*) FROM brands')->fetchColumn(),
];
$revenue = Database::run('SELECT COALESCE(SUM(total_amount), 0) FROM bookings WHERE payment_status = ?', ['paid'])->fetchColumn();
$revenueLastMonth = Database::run(
    'SELECT COALESCE(SUM(total_amount), 0) FROM bookings WHERE payment_status = ? AND pickup_date >= ? AND pickup_date < ?',
    ['paid', date('Y-m-01', strtotime('-1 month')), date('Y-m-01')]
)->fetchColumn();
$revenueChange = $revenueLastMonth > 0 ? round((($revenue - $revenueLastMonth) / $revenueLastMonth) * 100) : 0;

$recentBookings = Database::run(
    'SELECT b.id, b.pickup_date, b.return_date, b.total_amount, b.booking_status, b.payment_status, u.full_name AS customer_name, u.email AS customer_email, v.model AS vehicle_model, br.name AS brand_name
     FROM bookings b
     JOIN users u ON b.user_id = u.id
     JOIN vehicles v ON b.vehicle_id = v.id
     JOIN brands br ON v.brand_id = br.id
     ORDER BY b.created_at DESC LIMIT 8'
)->fetchAll();

$statusCounts = [
    'accepted' => (int) Database::run('SELECT COUNT(*) FROM bookings WHERE booking_status IN (\'confirmed\',\'active\',\'returned\',\'completed\') OR payment_status = ?', ['paid'])->fetchColumn(),
    'rejected' => (int) Database::run('SELECT COUNT(*) FROM bookings WHERE booking_status = ?', ['cancelled'])->fetchColumn(),
    'pending' => (int) Database::run('SELECT COUNT(*) FROM bookings WHERE booking_status = ?', ['pending'])->fetchColumn(),
];
$totalOrders = $statusCounts['accepted'] + $statusCounts['rejected'] + $statusCounts['pending'];
$user = Auth::user();
$greeting = $user ? 'Welcome back, ' . explode(' ', trim($user['name']))[0] : 'Dashboard';
$pageTitle = 'Dashboard';
require __DIR__ . '/layout/header.php';
?>
<div class="admin-dashboard-intro mb-3">
    <h1 class="admin-page-title mb-1"><?= Helpers::e($greeting) ?></h1>
    <p class="admin-page-subtitle text-muted">Overview of your fleet, bookings, and revenue.</p>
</div>
<?php $flash = Helpers::getFlash(); if ($flash): ?>
    <div class="admin-alert <?= $flash['type'] === 'error' ? 'danger' : 'success' ?>"><?= Helpers::e($flash['message']) ?></div>
<?php endif; ?>
<?php if (!empty($adminAlerts)): ?>
    <div class="admin-alert admin-alert-notifications mb-3">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
            <strong><i class="bi bi-exclamation-triangle-fill me-2"></i>Alerts</strong>
            <div class="d-flex flex-wrap gap-2">
                <a href="<?= \App\Helpers::baseUrl() ?>/admin/maintenance.php" class="btn btn-admin-outline btn-sm">Maintenance</a>
                <a href="<?= \App\Helpers::baseUrl() ?>/admin/bookings.php" class="btn btn-admin-outline btn-sm">Bookings</a>
            </div>
        </div>
        <ul class="mb-0 mt-2 ps-3">
            <?php foreach (array_slice($adminAlerts, 0, 5) as $a): ?>
                <li><?= Helpers::e($a['title']) ?> — <?= Helpers::e(mb_substr($a['message'], 0, 80)) ?><?= mb_strlen($a['message']) > 80 ? '…' : '' ?></li>
            <?php endforeach; ?>
        </ul>
        <?php if (count($adminAlerts) > 5): ?><p class="small text-muted mb-0 mt-1">+ <?= count($adminAlerts) - 5 ?> more</p><?php endif; ?>
    </div>
<?php endif; ?>

<div class="admin-quick-links mb-4">
    <a href="<?= \App\Helpers::baseUrl() ?>/admin/vehicles.php" class="admin-quick-link"><i class="bi bi-car-front"></i> Vehicles</a>
    <a href="<?= \App\Helpers::baseUrl() ?>/admin/bookings.php" class="admin-quick-link"><i class="bi bi-calendar-check"></i> Bookings</a>
    <a href="<?= \App\Helpers::baseUrl() ?>/admin/vehicle-edit.php" class="admin-quick-link"><i class="bi bi-plus-circle"></i> Add vehicle</a>
    <a href="<?= \App\Helpers::baseUrl() ?>/admin/reports.php" class="admin-quick-link"><i class="bi bi-file-earmark-bar-graph"></i> Reports</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="admin-card">
            <div class="card-label">Income</div>
            <div class="card-value">GHS <?= number_format((float)$revenue, 2) ?></div>
            <div class="card-change <?= $revenueChange >= 0 ? 'positive' : 'negative' ?>"><?= $revenueChange >= 0 ? '+' : '' ?><?= $revenueChange ?>% from last month</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="admin-card">
            <div class="card-label">Total Bookings</div>
            <div class="card-value"><?= $stats['bookings'] ?></div>
            <div class="card-change positive">All time</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="admin-card">
            <div class="card-label">Brands</div>
            <div class="card-value"><?= $stats['brands'] ?></div>
            <div class="card-change">Vehicle brands</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="admin-card">
            <div class="card-label">Pending</div>
            <div class="card-value"><?= $stats['pending_bookings'] ?></div>
            <div class="card-change negative">Awaiting confirmation</div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-lg-8">
        <div class="admin-card admin-card--padded">
            <div class="card-label mb-2">Fleet status</div>
            <div class="admin-stat-pills">
                <div class="admin-stat-pill teal">
                    <span class="icon-wrap"><i class="bi bi-car-front-fill"></i></span>
                    <div>
                        <div class="num"><?= $stats['available'] ?></div>
                        <div class="label">Cars Online</div>
                    </div>
                </div>
                <div class="admin-stat-pill orange">
                    <span class="icon-wrap"><i class="bi bi-clock-history"></i></span>
                    <div>
                        <div class="num"><?= $stats['pending_bookings'] ?></div>
                        <div class="label">On Order</div>
                    </div>
                </div>
                <div class="admin-stat-pill red">
                    <span class="icon-wrap"><i class="bi bi-pause-circle"></i></span>
                    <div>
                        <div class="num"><?= $stats['unavailable'] ?></div>
                        <div class="label">Awaiting</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="admin-chart-card">
            <div class="chart-title">Total Revenue</div>
            <div class="chart-subtitle">GHS <?= number_format((float)$revenue, 2) ?> · <?= $revenueChange >= 0 ? '+' : '' ?><?= $revenueChange ?>%</div>
            <canvas id="revenueChart" height="140"></canvas>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-lg-6">
        <div class="admin-chart-card">
            <div class="chart-title">Bookings overview</div>
            <div class="chart-subtitle">By status</div>
            <?php if ($totalOrders > 0): ?>
                <canvas id="donutChart" height="200"></canvas>
            <?php else: ?>
                <div class="chart-empty">No bookings yet. Data will appear here once you have orders.</div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="admin-chart-card">
            <div class="chart-title">Fleet &amp; bookings</div>
            <div class="chart-subtitle">Key metrics</div>
            <canvas id="barChart" height="200"></canvas>
        </div>
    </div>
</div>

<div class="admin-table-wrap">
    <div class="card-header">
        <div>
            <span class="d-block">Recent Bookings</span>
            <small class="text-muted fw-normal">Keep track of booking and passengers data.</small>
        </div>
        <a href="<?= \App\Helpers::baseUrl() ?>/admin/bookings.php" class="btn btn-admin-primary btn-sm">View All Bookings</a>
    </div>
    <div class="table-responsive">
        <table class="table admin-table">
            <thead>
                <tr>
                    <th>Booking #</th>
                    <th>Passenger</th>
                    <th>Date</th>
                    <th>Vehicle</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentBookings as $b): ?>
                    <tr>
                        <td><strong>#<?= (int)$b['id'] ?></strong></td>
                        <td>
                            <div><?= Helpers::e($b['customer_name']) ?></div>
                            <small class="text-muted"><?= Helpers::e($b['customer_email']) ?></small>
                        </td>
                        <td><?= date('d M Y', strtotime($b['pickup_date'])) ?></td>
                        <td><?= Helpers::e($b['brand_name'] ?? '') ?> · <?= Helpers::e($b['vehicle_model']) ?></td>
                        <td>GHS <?= number_format((float)$b['total_amount'], 2) ?></td>
                        <td><span class="status-pill <?= Helpers::e(Helpers::bookingStatusPillClass($b['booking_status'] ?? '')) ?>"><?= Helpers::e(Helpers::humanizeSnake($b['booking_status'] ?? '')) ?></span></td>
                        <td>
                            <a href="<?= \App\Helpers::baseUrl() ?>/admin/bookings.php" class="btn btn-admin-outline btn-sm py-1 px-2"><i class="bi bi-three-dots"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($recentBookings)): ?>
                    <tr><td colspan="7" class="text-muted py-4 text-center">No bookings yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
(function(){
    Chart.defaults.color = '#98989d';
    Chart.defaults.borderColor = '#38383a';
    Chart.defaults.font.size = 14;

    var revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        new Chart(revenueCtx, {
            type: 'bar',
            data: {
                labels: ['Vehicles', 'Available', 'Bookings', 'Pending', 'Brands'],
                datasets: [{
                    label: 'Count',
                    data: [<?= $stats['vehicles'] ?>, <?= $stats['available'] ?>, <?= $stats['bookings'] ?>, <?= $stats['pending_bookings'] ?>, <?= $stats['brands'] ?>],
                    backgroundColor: ['#34c7b4','#30d158','#ff9f43','#ffd60a','#98989d']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                scales: { y: { beginAtZero: true, ticks: { font: { size: 14 } } }, x: { ticks: { font: { size: 14 } } } },
                plugins: { legend: { display: false } }
            }
        });
    }

    var donutCtx = document.getElementById('donutChart');
    if (donutCtx && <?= $totalOrders ?> > 0) {
        new Chart(donutCtx, {
            type: 'doughnut',
            data: {
                labels: ['Accepted', 'Rejected', 'Pending'],
                datasets: [{
                    data: [<?= $statusCounts['accepted'] ?>, <?= $statusCounts['rejected'] ?>, <?= $statusCounts['pending'] ?>],
                    backgroundColor: ['#34c7b4', '#ff6b6b', '#98989d']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                cutout: '65%',
                plugins: { legend: { position: 'bottom', labels: { font: { size: 14 } } } }
            }
        });
    }

    var barCtx = document.getElementById('barChart');
    if (barCtx) {
        new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: ['Vehicles', 'Available', 'Bookings', 'Brands'],
                datasets: [{
                    label: 'Count',
                    data: [<?= $stats['vehicles'] ?>, <?= $stats['available'] ?>, <?= $stats['bookings'] ?>, <?= $stats['brands'] ?>],
                    backgroundColor: '#2c2c2e',
                    borderColor: '#34c7b4',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                scales: { y: { beginAtZero: true, ticks: { font: { size: 14 } } }, x: { ticks: { font: { size: 14 } } } },
                plugins: { legend: { display: false } }
            }
        });
    }
})();
</script>
<?php require __DIR__ . '/layout/footer.php'; ?>
