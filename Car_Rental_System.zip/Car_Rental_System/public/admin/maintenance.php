<?php
require_once dirname(dirname(__DIR__)) . '/bootstrap.php';

use App\Auth;
use App\Csrf;
use App\Database;
use App\Helpers;
use App\ActivityLog;
use App\Notification;

Auth::requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Csrf::validateOrAbort();
    if (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        Database::run('DELETE FROM maintenance WHERE id = ?', [$id]);
        ActivityLog::log('maintenance_delete', 'maintenance', $id);
        Helpers::flash('success', 'Task deleted.');
    } elseif (isset($_POST['add']) || isset($_POST['edit_id'])) {
        $vehicleId = (int)($_POST['vehicle_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '') ?: null;
        $scheduledDate = trim($_POST['scheduled_date'] ?? '') ?: null;
        $staffId = !empty($_POST['staff_id']) ? (int)$_POST['staff_id'] : null;
        $maintenanceType = in_array($_POST['maintenance_type'] ?? '', ['routine','repair','accident','inspection'], true) ? $_POST['maintenance_type'] : 'routine';
        $priority = in_array($_POST['priority'] ?? '', ['low','medium','high','emergency'], true) ? $_POST['priority'] : 'medium';
        $status = in_array($_POST['status'] ?? '', ['scheduled','in_progress','completed','cancelled'], true) ? $_POST['status'] : 'scheduled';
        if ($vehicleId && $title !== '') {
            if (isset($_POST['edit_id']) && (int)$_POST['edit_id'] > 0) {
                $id = (int)$_POST['edit_id'];
                Database::run('UPDATE maintenance SET vehicle_id=?, staff_id=?, title=?, description=?, maintenance_type=?, priority=?, scheduled_date=?, status=? WHERE id=?', [$vehicleId, $staffId, $title, $description, $maintenanceType, $priority, $scheduledDate, $status, $id]);
                ActivityLog::log('maintenance_update', 'maintenance', $id);
                Helpers::flash('success', 'Task updated.');
            } else {
                Database::run('INSERT INTO maintenance (vehicle_id, staff_id, title, description, maintenance_type, priority, scheduled_date, status) VALUES (?,?,?,?,?,?,?,?)', [$vehicleId, $staffId, $title, $description, $maintenanceType, $priority, $scheduledDate, $status]);
                $maintenanceId = (int)Database::pdo()->lastInsertId();
                ActivityLog::log('maintenance_create', 'maintenance', $maintenanceId);
                $vehicleInfo = Database::run('SELECT CONCAT(b.name, " ", v.model) AS name FROM vehicles v JOIN brands b ON v.brand_id = b.id WHERE v.id = ?', [$vehicleId])->fetchColumn();
                Notification::notifyVehicleMaintenance($maintenanceId, $vehicleInfo ?: "Vehicle #{$vehicleId}", 'Vehicle in for maintenance');
                Helpers::flash('success', 'Task added.');
            }
        }
    }
    Helpers::redirect(Helpers::baseUrl() . '/admin/maintenance.php');
}

$tasks = Database::run(
    'SELECT m.*, v.model AS vehicle_model, v.registration_number, s.full_name AS staff_name
     FROM maintenance m
     JOIN vehicles v ON m.vehicle_id = v.id
     LEFT JOIN staff s ON m.staff_id = s.id
     ORDER BY m.scheduled_date IS NULL, m.scheduled_date ASC'
)->fetchAll();
$vehicles = Database::run('SELECT v.id, v.model, v.registration_number, b.name AS brand_name FROM vehicles v JOIN brands b ON v.brand_id = b.id ORDER BY b.name, v.model')->fetchAll();
$staffList = Database::run('SELECT id, full_name FROM staff WHERE is_active = 1 ORDER BY full_name')->fetchAll();

$pageTitle = 'Maintenance';
require __DIR__ . '/layout/header.php';
?>
<h1 class="admin-page-title">Maintenance</h1>
<?php $flash = Helpers::getFlash(); if ($flash): ?>
    <div class="admin-alert <?= $flash['type'] === 'error' ? 'danger' : 'success' ?>"><?= Helpers::e($flash['message']) ?></div>
<?php endif; ?>
<div class="admin-card mb-4">
    <h5 class="mb-3">Add task</h5>
    <form method="post">
        <?= Csrf::field() ?>
        <input type="hidden" name="add" value="1">
        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Vehicle</label>
                <select name="vehicle_id" class="form-select" required>
                    <option value="">-- Select --</option>
                    <?php foreach ($vehicles as $v): ?>
                        <option value="<?= (int)$v['id'] ?>"><?= Helpers::e($v['brand_name']) ?> <?= Helpers::e($v['model']) ?> (<?= Helpers::e($v['registration_number'] ?? '—') ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Assign to</label>
                <select name="staff_id" class="form-select">
                    <option value="">Unassigned</option>
                    <?php foreach ($staffList as $s): ?>
                        <option value="<?= (int)$s['id'] ?>"><?= Helpers::e($s['full_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Type</label>
                <select name="maintenance_type" class="form-select">
                    <option value="routine">Routine</option>
                    <option value="repair">Repair</option>
                    <option value="accident">Accident</option>
                    <option value="inspection">Inspection</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Priority</label>
                <select name="priority" class="form-select">
                    <option value="low">Low</option>
                    <option value="medium" selected>Medium</option>
                    <option value="high">High</option>
                    <option value="emergency">Emergency</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Scheduled date</label>
                <input type="date" name="scheduled_date" class="form-control">
            </div>
            <div class="col-12">
                <label class="form-label">Title</label>
                <input type="text" name="title" class="form-control" required placeholder="e.g. Oil change">
            </div>
            <div class="col-12">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="2"></textarea>
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-admin-primary">Add task</button>
            </div>
        </div>
    </form>
</div>
<div class="admin-table-wrap">
    <div class="table-responsive">
        <table class="table admin-table">
            <thead><tr><th>Vehicle</th><th>Title</th><th>Type</th><th>Scheduled</th><th>Assigned</th><th>Status</th><th></th></tr></thead>
            <tbody>
                <?php foreach ($tasks as $t): ?>
                    <tr>
                        <td><?= Helpers::e($t['vehicle_model']) ?> (<?= Helpers::e($t['registration_number'] ?? '—') ?>)</td>
                        <td><?= Helpers::e($t['title']) ?></td>
                        <td><?= Helpers::e($t['maintenance_type']) ?></td>
                        <td><?= $t['scheduled_date'] ? Helpers::e($t['scheduled_date']) : '—' ?></td>
                        <td><?= Helpers::e($t['staff_name'] ?? '—') ?></td>
                        <td><span class="status-pill <?= $t['status'] === 'completed' ? 'completed' : ($t['status'] === 'cancelled' ? 'cancelled' : 'waiting') ?>"><?= Helpers::e($t['status']) ?></span></td>
                        <td>
                            <form method="post" class="d-inline" onsubmit="return confirm('Delete this task?');">
                                <?= Csrf::field() ?>
                                <input type="hidden" name="delete_id" value="<?= (int)$t['id'] ?>">
                                <button type="submit" class="btn btn-admin-outline btn-sm text-danger border-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($tasks)): ?><tr><td colspan="7" class="text-muted py-4 text-center">No maintenance tasks.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require __DIR__ . '/layout/footer.php'; ?>
