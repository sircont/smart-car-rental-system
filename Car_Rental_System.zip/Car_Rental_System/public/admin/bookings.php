<?php
require_once dirname(dirname(__DIR__)) . '/bootstrap.php';

use App\Auth;
use App\Booking;
use App\Csrf;
use App\Database;
use App\Helpers;

Auth::requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Csrf::validateOrAbort();
    if (isset($_POST['confirm_booking_return'])) {
        $bid = (int) ($_POST['booking_id'] ?? 0);
        $row = Database::run('SELECT return_requested_at, booking_status FROM bookings WHERE id = ?', [$bid])->fetch();
        if ($row && $row['booking_status'] !== 'completed'
            && (($row['booking_status'] ?? '') === 'returned' || !empty($row['return_requested_at']))) {
            Booking::markCompleted($bid);
            Helpers::flash('success', 'Return confirmed. Booking completed and vehicle marked available.');
        } else {
            Helpers::flash('error', 'No pending customer return request for this booking.');
        }
    } elseif (isset($_POST['update_booking_status'])) {
        $bid = (int)$_POST['booking_id'];
        $status = $_POST['booking_status'] ?? '';
        if (in_array($status, ['pending','confirmed','active','returned','completed','cancelled','no_show'], true)) {
            if ($status === 'completed') {
                Booking::markCompleted($bid);
            } else {
                Database::run('UPDATE bookings SET booking_status = ? WHERE id = ?', [$status, $bid]);
            }
            Helpers::flash('success', 'Booking status updated.');
        }
    } elseif (isset($_POST['update_payment_status'])) {
        $bid = (int)$_POST['booking_id'];
        $status = $_POST['payment_status'] ?? '';
        if (in_array($status, ['pending','partial','paid','refunded'], true)) {
            Database::run('UPDATE bookings SET payment_status = ? WHERE id = ?', [$status, $bid]);
            Helpers::flash('success', 'Payment status updated.');
        }
    }
    $redirect = Helpers::baseUrl() . '/admin/bookings.php';
    if (!empty($_POST['_search_keep'])) {
        $redirect .= '?search=' . urlencode(trim((string) $_POST['_search_keep']));
    }
    Helpers::redirect($redirect);
}

$searchQuery = isset($_GET['search']) ? trim((string) $_GET['search']) : '';
$params = [];
$sql = 'SELECT b.*, u.full_name AS customer_name, u.email AS customer_email, v.model AS vehicle_model, v.registration_number
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN vehicles v ON b.vehicle_id = v.id';
if ($searchQuery !== '') {
    $like = '%' . $searchQuery . '%';
    $sql .= ' WHERE (u.full_name LIKE ? OR u.email LIKE ? OR b.booking_number LIKE ? OR v.model LIKE ? OR v.registration_number LIKE ? OR CAST(b.id AS CHAR) = ?)';
    $params = array_merge($params, [$like, $like, $like, $like, $like, $searchQuery]);
}
$sql .= ' ORDER BY b.created_at DESC';
$bookings = Database::run($sql, $params)->fetchAll();

$pageTitle = 'Bookings';
require __DIR__ . '/layout/header.php';
?>
<h1 class="admin-page-title">Bookings</h1>
<?php $flash = Helpers::getFlash(); if ($flash): ?>
    <div class="admin-alert <?= $flash['type'] === 'error' ? 'danger' : 'success' ?>"><?= Helpers::e($flash['message']) ?></div>
<?php endif; ?>

<form method="get" action="<?= Helpers::e(Helpers::baseUrl() . '/admin/bookings.php') ?>" class="admin-bookings-filter mb-4">
    <div class="admin-filter-row">
        <div class="admin-filter-search">
            <i class="bi bi-search"></i>
            <input type="text" name="search" value="<?= Helpers::e($searchQuery) ?>" placeholder="Search by customer, email, booking #, vehicle, registration…" class="form-control" aria-label="Search bookings">
        </div>
        <button type="submit" class="btn btn-admin-primary">Search</button>
        <?php if ($searchQuery !== ''): ?>
            <a href="<?= Helpers::e(Helpers::baseUrl() . '/admin/bookings.php') ?>" class="btn btn-admin-outline">Clear</a>
        <?php endif; ?>
    </div>
    <?php if ($searchQuery !== ''): ?>
        <p class="admin-filter-hint text-muted mb-0 mt-2"><?= count($bookings) ?> result(s) for “<?= Helpers::e($searchQuery) ?>”.</p>
    <?php endif; ?>
</form>

<div class="admin-table-wrap">
    <div class="table-responsive">
        <table class="table admin-table">
            <thead>
                <tr><th>Vehicle</th><th>Pickup</th><th>Return</th><th>Amount (GHS)</th><th>Booking</th><th>Payment</th><th>Customer return</th><th>Action</th></tr>
            </thead>
            <tbody>
                <?php foreach ($bookings as $b): ?>
                    <tr>
                        <td>
                            <div><?= Helpers::e($b['vehicle_model']) ?> (<?= Helpers::e($b['registration_number'] ?? '—') ?>)</div>
                            <small class="text-muted d-block"><?= Helpers::e($b['customer_name']) ?></small>
                            <?php if (!empty($b['booking_number'])): ?>
                                <small class="text-muted d-block"><?= Helpers::e($b['booking_number']) ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?= Helpers::e($b['pickup_date']) ?></td>
                        <td><?= Helpers::e($b['return_date']) ?></td>
                        <td><?= number_format((float)($b['total_amount'] ?? 0), 2) ?></td>
                        <td><span class="status-pill <?= Helpers::e(Helpers::bookingStatusPillClass($b['booking_status'] ?? '')) ?>"><?= Helpers::e(Helpers::humanizeSnake($b['booking_status'] ?? '')) ?></span></td>
                        <td><span class="status-pill <?= Helpers::e(Helpers::paymentStatusPillClass($b['payment_status'] ?? '')) ?>"><?= Helpers::e(Helpers::humanizeSnake($b['payment_status'] ?? '')) ?></span></td>
                        <td>
                            <?php if (($b['booking_status'] ?? '') === 'completed'): ?>
                                <span class="status-pill completed d-inline-block">Return confirmed</span>
                            <?php elseif (($b['booking_status'] ?? '') === 'returned' || (!empty($b['return_requested_at']) && ($b['booking_status'] ?? '') !== 'completed')): ?>
                                <span class="status-pill pending d-inline-block">Return reported</span>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="admin-bookings-action-panel">
                            <details class="admin-bookings-row-manage">
                                <summary class="admin-bookings-action-summary" aria-label="Booking #<?= (int)$b['id'] ?> actions">
                                    <span class="admin-bookings-chip-btn"><?= Helpers::e(Helpers::humanizeSnake($b['booking_status'] ?? '')) ?></span>
                                    <span class="admin-bookings-chip-btn"><?= Helpers::e(Helpers::humanizeSnake($b['payment_status'] ?? '')) ?></span>
                                </summary>
                                <div class="admin-bookings-manage-panel">
                                    <div class="admin-bookings-action-block">
                                        <span class="admin-bookings-action-label">Booking</span>
                                        <form method="post" class="admin-bookings-action-form">
                                            <?= Csrf::field() ?>
                                            <?php if ($searchQuery !== ''): ?><input type="hidden" name="_search_keep" value="<?= Helpers::e($searchQuery) ?>"><?php endif; ?>
                                            <input type="hidden" name="booking_id" value="<?= (int)$b['id'] ?>">
                                            <input type="hidden" name="update_booking_status" value="1">
                                            <select name="booking_status" class="form-select form-select-sm" aria-label="Booking status #<?= (int)$b['id'] ?>">
                                                <option value="pending" <?= $b['booking_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                                <option value="confirmed" <?= $b['booking_status'] === 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
                                                <option value="active" <?= $b['booking_status'] === 'active' ? 'selected' : '' ?>>Active</option>
                                                <option value="returned" <?= $b['booking_status'] === 'returned' ? 'selected' : '' ?>>Returned</option>
                                                <option value="completed" <?= $b['booking_status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                                                <option value="cancelled" <?= $b['booking_status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                                <option value="no_show" <?= $b['booking_status'] === 'no_show' ? 'selected' : '' ?>>No show</option>
                                            </select>
                                            <button type="submit" class="btn btn-admin-primary btn-sm">Update booking</button>
                                        </form>
                                    </div>
                                    <div class="admin-bookings-action-block">
                                        <span class="admin-bookings-action-label">Payment</span>
                                        <form method="post" class="admin-bookings-action-form">
                                            <?= Csrf::field() ?>
                                            <?php if ($searchQuery !== ''): ?><input type="hidden" name="_search_keep" value="<?= Helpers::e($searchQuery) ?>"><?php endif; ?>
                                            <input type="hidden" name="booking_id" value="<?= (int)$b['id'] ?>">
                                            <input type="hidden" name="update_payment_status" value="1">
                                            <select name="payment_status" class="form-select form-select-sm" aria-label="Payment status #<?= (int)$b['id'] ?>">
                                                <option value="pending" <?= $b['payment_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                                                <option value="partial" <?= $b['payment_status'] === 'partial' ? 'selected' : '' ?>>Partial</option>
                                                <option value="paid" <?= $b['payment_status'] === 'paid' ? 'selected' : '' ?>>Paid</option>
                                                <option value="refunded" <?= $b['payment_status'] === 'refunded' ? 'selected' : '' ?>>Refunded</option>
                                            </select>
                                            <button type="submit" class="btn btn-admin-outline btn-sm">Update payment</button>
                                        </form>
                                    </div>
                                    <div class="admin-bookings-action-block">
                                        <span class="admin-bookings-action-label">Return</span>
                                        <?php if (($b['booking_status'] ?? '') === 'completed'): ?>
                                            <span class="admin-bookings-action-muted">—</span>
                                        <?php elseif (($b['booking_status'] ?? '') === 'returned' || (!empty($b['return_requested_at']) && ($b['booking_status'] ?? '') !== 'completed')): ?>
                                            <form method="post" class="admin-bookings-action-form admin-bookings-action-form--single">
                                                <?= Csrf::field() ?>
                                                <?php if ($searchQuery !== ''): ?><input type="hidden" name="_search_keep" value="<?= Helpers::e($searchQuery) ?>"><?php endif; ?>
                                                <input type="hidden" name="booking_id" value="<?= (int)$b['id'] ?>">
                                                <input type="hidden" name="confirm_booking_return" value="1">
                                                <button type="submit" class="btn btn-sm btn-admin-confirm-return">Confirm return</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="admin-bookings-action-muted">—</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </details>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($bookings)): ?>
                    <tr><td colspan="8" class="text-muted py-4 text-center"><?= $searchQuery !== '' ? 'No bookings match your search.' : 'No bookings yet.' ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require __DIR__ . '/layout/footer.php'; ?>
