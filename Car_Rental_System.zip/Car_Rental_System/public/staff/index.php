<?php
require_once dirname(dirname(__DIR__)) . '/bootstrap.php';

use App\Auth;
use App\Database;
use App\Helpers;
use App\Notification;

Auth::requireStaff();
$staffAlerts = Notification::getUnreadForStaff();

$userId = Auth::id();
$tasksPending = (int) Database::run('SELECT COUNT(*) FROM maintenance WHERE (staff_id = ? OR staff_id IS NULL) AND status IN (\'scheduled\',\'in_progress\')', [$userId])->fetchColumn();
$tasksMine = (int) Database::run('SELECT COUNT(*) FROM maintenance WHERE staff_id = ? AND status IN (\'scheduled\',\'in_progress\')', [$userId])->fetchColumn();
$bookingsToday = (int) Database::run('SELECT COUNT(*) FROM bookings WHERE payment_status = ? AND DATE(pickup_date) = CURDATE()', ['paid'])->fetchColumn();
$bookingsUpcoming = (int) Database::run('SELECT COUNT(*) FROM bookings WHERE payment_status = ? AND pickup_date > NOW()', ['paid'])->fetchColumn();

$upcomingBookings = Database::run(
    'SELECT b.id, b.pickup_date, b.return_date, u.full_name AS customer_name, v.model AS vehicle_model, v.registration_number, b.booking_status, b.payment_status
     FROM bookings b
     JOIN users u ON b.user_id = u.id
     JOIN vehicles v ON b.vehicle_id = v.id
     WHERE b.payment_status = ? AND b.pickup_date >= CURDATE()
     ORDER BY b.pickup_date ASC LIMIT 10',
    ['paid']
)->fetchAll();

$myTasks = Database::run(
    'SELECT m.*, v.model AS vehicle_model, v.registration_number FROM maintenance m JOIN vehicles v ON m.vehicle_id = v.id WHERE m.staff_id = ? AND m.status IN (\'scheduled\',\'in_progress\') ORDER BY m.scheduled_date ASC LIMIT 5',
    [$userId]
)->fetchAll();

$pageTitle = 'Dashboard';
require __DIR__ . '/layout/header.php';
?>
<h1 class="admin-page-title">Staff Dashboard</h1>
<?php $flash = Helpers::getFlash(); if ($flash): ?>
    <div class="admin-alert <?= $flash['type'] === 'error' ? 'danger' : 'success' ?>"><?= Helpers::e($flash['message']) ?></div>
<?php endif; ?>
<?php if (!empty($staffAlerts)): ?>
    <div class="admin-alert admin-alert-notifications mb-4">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
            <strong><i class="bi bi-exclamation-triangle-fill me-2"></i>Alerts</strong>
            <div class="d-flex flex-wrap gap-2">
                <a href="<?= \App\Helpers::baseUrl() ?>/staff/maintenance.php" class="btn btn-admin-outline btn-sm">Maintenance</a>
                <a href="<?= \App\Helpers::baseUrl() ?>/staff/bookings.php" class="btn btn-admin-outline btn-sm">Bookings</a>
            </div>
        </div>
        <ul class="mb-0 mt-2 ps-3">
            <?php foreach (array_slice($staffAlerts, 0, 5) as $a): ?>
                <li><?= Helpers::e($a['title']) ?> — <?= Helpers::e(mb_substr($a['message'], 0, 80)) ?><?= mb_strlen($a['message']) > 80 ? '…' : '' ?></li>
            <?php endforeach; ?>
        </ul>
        <?php if (count($staffAlerts) > 5): ?><p class="small text-muted mb-0 mt-1">+ <?= count($staffAlerts) - 5 ?> more</p><?php endif; ?>
    </div>
<?php endif; ?>

<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="admin-card">
            <div class="card-label">My tasks</div>
            <div class="card-value"><?= $tasksMine ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="admin-card">
            <div class="card-label">All pending tasks</div>
            <div class="card-value"><?= $tasksPending ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="admin-card">
            <div class="card-label">Pickups today</div>
            <div class="card-value"><?= $bookingsToday ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="admin-card">
            <div class="card-label">Upcoming bookings</div>
            <div class="card-value"><?= $bookingsUpcoming ?></div>
        </div>
    </div>
</div>
<div class="row g-3">
    <div class="col-lg-6">
        <div class="admin-table-wrap">
            <div class="card-header">Upcoming bookings</div>
            <div class="table-responsive">
                <table class="table admin-table">
                    <thead><tr><th>Date</th><th>Customer</th><th>Vehicle</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php foreach ($upcomingBookings as $b): ?>
                            <tr>
                                <td><?= Helpers::e($b['pickup_date']) ?></td>
                                <td><?= Helpers::e($b['customer_name']) ?></td>
                                <td><?= Helpers::e($b['vehicle_model']) ?> (<?= Helpers::e($b['registration_number'] ?? '—') ?>)</td>
                                <td><span class="status-pill <?= Helpers::e(Helpers::bookingStatusPillClass($b['booking_status'] ?? '')) ?>"><?= Helpers::e(Helpers::humanizeSnake($b['booking_status'] ?? '')) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($upcomingBookings)): ?><tr><td colspan="4" class="text-muted py-3 text-center">No upcoming bookings.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="admin-table-wrap">
            <div class="card-header">My maintenance tasks</div>
            <div class="table-responsive">
                <table class="table admin-table">
                    <thead><tr><th>Vehicle</th><th>Title</th><th>Scheduled</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php foreach ($myTasks as $t): ?>
                            <tr>
                                <td><?= Helpers::e($t['vehicle_model']) ?> (<?= Helpers::e($t['registration_number'] ?? '—') ?>)</td>
                                <td><?= Helpers::e($t['title']) ?></td>
                                <td><?= $t['scheduled_date'] ? Helpers::e($t['scheduled_date']) : '—' ?></td>
                                <td><span class="status-pill <?= $t['status'] === 'in_progress' ? 'waiting' : 'secondary' ?>"><?= Helpers::e($t['status']) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($myTasks)): ?><tr><td colspan="4" class="text-muted py-3 text-center">No tasks assigned.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/layout/footer.php'; ?>
