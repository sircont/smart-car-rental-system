<?php
namespace App;

final class Helpers
{
    public static function baseUrl(): string
    {
        $config = require dirname(__DIR__) . '/config/app.php';
        return rtrim((string)($config['url'] ?? ''), '/');
    }

    public static function e(string $s): string
    {
        return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    }

    public static function redirect(string $url, int $code = 302): void
    {
        header('Location: ' . $url, true, $code);
        exit;
    }

    public static function flash(string $type, string $message): void
    {
        $_SESSION['_flash'] = ['type' => $type, 'message' => $message];
    }

    public static function getFlash(): ?array
    {
        $v = $_SESSION['_flash'] ?? null;
        unset($_SESSION['_flash']);
        return $v;
    }

    public static function old(string $key, string $default = ''): string
    {
        return isset($_SESSION['_old'][$key]) ? (string) $_SESSION['_old'][$key] : $default;
    }

    public static function setOld(array $data): void
    {
        $_SESSION['_old'] = $data;
    }

    /** CSS class for admin/staff booking status pills (matches .status-pill.* in admin.css). */
    public static function bookingStatusPillClass(?string $status): string
    {
        $s = strtolower(trim((string) $status));
        $map = [
            'completed' => 'completed',
            'cancelled' => 'cancelled',
            'confirmed' => 'confirmed',
            'active' => 'active',
            'returned' => 'returned',
            'pending' => 'pending',
            'no_show' => 'secondary',
        ];
        return $map[$s] ?? 'secondary';
    }

    /** CSS class for payment status pills on booking rows. */
    public static function paymentStatusPillClass(?string $status): string
    {
        $s = strtolower(trim((string) $status));
        $map = [
            'paid' => 'paid',
            'partial' => 'pending',
            'pending' => 'pending',
            'refunded' => 'secondary',
        ];
        return $map[$s] ?? 'secondary';
    }

    /** e.g. no_show → No show (for table display). */
    public static function humanizeSnake(?string $value): string
    {
        $v = trim((string) $value);
        if ($v === '') {
            return '—';
        }
        return ucwords(str_replace('_', ' ', strtolower($v)));
    }

    /** Single line for booking pickup/return location from a branch row. */
    public static function branchLocationLabel(array $branch): string
    {
        $name = trim((string) ($branch['name'] ?? ''));
        $addr = trim((string) ($branch['address'] ?? ''));
        $phone = trim((string) ($branch['phone'] ?? ''));
        $line = $name;
        if ($addr !== '') {
            $line .= ($line !== '' ? ' — ' : '') . $addr;
        }
        if ($phone !== '') {
            $line .= ($line !== '' ? ' · ' : '') . $phone;
        }
        return $line !== '' ? $line : 'Branch';
    }
}
