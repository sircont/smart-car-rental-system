# Chapter 4 — Diagram sources (Mermaid)

Paste any block into [mermaid.live](https://mermaid.live) or use `render-figures.html`.

---

## Figure 4.1 — System context

External actors interact with the web application on the server; the application uses MySQL.

```mermaid
flowchart LR
  C[Customer]
  S[Staff]
  A[Admin]
  subgraph Server["Web server (Apache + PHP)"]
    APP[Smart Car Rental\napplication]
  end
  DB[(MySQL\ndatabase)]
  C -->|HTTPS / Browser| APP
  S -->|HTTPS / Browser| APP
  A -->|HTTPS / Browser| APP
  APP <-->|SQL queries| DB
```

---

## Figure 4.2 — Use case diagram

```mermaid
flowchart TB
  subgraph SYS["Smart Car Rental System"]
    direction TB
    uc1[Browse & search vehicles]
    uc2[Check availability]
    uc3[Register / Login / Profile]
    uc4[Create & view bookings]
    uc5[Maintenance & checklist]
    uc6[Check-in / Check-out]
    uc7[Manage fleet & branches]
    uc8[Manage users & staff]
    uc9[Bookings & payments oversight]
    uc10[Reports & activity logs]
  end
  Customer[Customer]
  Staff[Staff]
  Admin[Admin]
  Customer --> uc1
  Customer --> uc2
  Customer --> uc3
  Customer --> uc4
  Staff --> uc5
  Staff --> uc6
  Staff --> uc4
  Admin --> uc7
  Admin --> uc8
  Admin --> uc9
  Admin --> uc10
```

---

## Figure 4.3 — Data flow diagram: customer booking (high level)

```mermaid
flowchart LR
  C[Customer]
  P1["1.0 Select vehicle\n& dates"]
  P2["2.0 Validate &\ncheck availability"]
  P3["3.0 Create booking"]
  D_V[(D1 Vehicles)]
  D_B[(D2 Bookings)]
  C -->|Menu, dates| P1
  P1 --> P2
  P2 <-->|Read| D_V
  P2 <-->|Read/Write| D_B
  P3 <-->|Insert| D_B
  P2 -->|Available / not| P1
  P3 -->|Confirmation| C
  P1 --> P3
```

---

## Figure 4.4 — Data flow diagram: admin management (high level)

```mermaid
flowchart LR
  A[Administrator]
  P1["4.0 Manage catalog\n& configuration"]
  P2["5.0 Manage users\n& staff"]
  P3["6.0 Monitor bookings\n& payments"]
  P4["7.0 Reports &\nactivity logs"]
  D_U[(Users / Staff)]
  D_V[(Vehicles / Brands)]
  D_B[(Bookings)]
  D_P[(Payments)]
  D_L[(Activity logs)]
  A -->|Requests| P1
  A -->|Requests| P2
  A -->|Requests| P3
  A -->|Requests| P4
  P1 <--> D_V
  P2 <--> D_U
  P3 <--> D_B
  P3 <--> D_P
  P4 <--> D_B
  P4 <--> D_L
  P1 -->|Updated UI data| A
  P2 -->|Updated UI data| A
  P3 -->|Updated UI data| A
  P4 -->|Charts / lists| A
```

---

## Figure 4.5 — Entity-relationship diagram (core entities)

Aligned with `database/schema.sql` (primary relationships).

```mermaid
erDiagram
    users ||--o{ bookings : "places"
    vehicles ||--o{ bookings : "reserved_as"
    bookings ||--o{ payments : "paid_via"
    brands ||--o{ vehicles : "brand_of"
    vehicles ||--o{ maintenance : "requires"
    staff ||--o{ maintenance : "assigned"
```

---

### Optional: stricter cardinality note

One booking may have multiple payment rows over time; the diagram uses `||--o{` to allow several payments per booking. Adjust to one-to-one in your report only if your business rule enforces a single payment row per booking.
