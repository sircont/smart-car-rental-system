# Figures 4.6–4.x — UI screenshots (you capture these)

Diagrams 4.1–4.5 are provided as Mermaid in this folder. **Login, registration, listing, booking, admin, and reports** must be **screenshots** of your running application so they match your real UI.

## Before you start

1. Start **Apache** and **MySQL** in XAMPP.
2. Base URL (default from `config/app.php`):  
   `http://localhost/Car_Rental_System/public`
3. Log in as **customer** and **admin** with your test accounts.
4. Use **full window** or a consistent width; hide bookmarks bar if you want a cleaner figure.

## Suggested mapping

| Figure | What to show | URL (append to base) |
|--------|----------------|----------------------|
| **4.6** | Login page | `/login.php` |
| **4.7** | Registration | `/register.php` |
| **4.8** | Vehicle listing / catalog | `/cars.php` |
| **4.9** | Booking flow (dates + vehicle) | `/book.php?vehicle=1` (use a valid vehicle id from your DB) |
| **4.10** | Customer booking history (optional extra) | `/my-bookings.php` |
| **4.11** | Admin dashboard | `/admin/index.php` |
| **4.12** | Admin reports | `/admin/reports.php` |

Adjust figure numbers in your thesis table of figures if you add or drop a screen.

## Tips

- **Windows:** `Win + Shift + S` for a region screenshot, or Snipping Tool.
- Save as **PNG** (`fig-4-6-login.png`, etc.) and insert into Word with a **caption** “Figure 4.6: Login page”.
- If the admin area is empty, seed a few vehicles/bookings first so charts and tables look meaningful.
