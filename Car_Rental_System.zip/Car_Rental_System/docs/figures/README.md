# Chapter 4 figures — Smart Car Rental System

## What you get here

| Figure | File / source |
|--------|----------------|
| **4.1** System context | `figures-chapter-4.md` or `render-figures.html` |
| **4.2** Use case diagram | same |
| **4.3** DFD — customer booking | same |
| **4.4** DFD — admin management | same |
| **4.5** ERD — core entities | same (matches `database/schema.sql`) |
| **4.6+** UI screenshots | You capture from a running app — see `SCREENSHOT_CHECKLIST.md` |

## How to export diagrams as PNG/PDF

1. **Easiest:** Open **`render-figures.html`** in Chrome or Edge (double-click or drag into the browser). Use **Print → Save as PDF**, or zoom and screenshot each diagram.
2. **High quality:** Copy a `mermaid` code block from **`figures-chapter-4.md`** into [mermaid.live](https://mermaid.live) → **Actions → PNG/SVG**.

## VS Code / Cursor

Install a Mermaid preview extension and open `figures-chapter-4.md` to preview, then export if the extension supports it.
