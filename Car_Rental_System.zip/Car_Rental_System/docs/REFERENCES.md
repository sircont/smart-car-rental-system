# Verifiable references (26 sources)

Use the citation style your department requires (**APA 7th**, **Harvard**, or **IEEE**). Every entry can be checked via **ISBN**, **DOI** (`https://doi.org/…`), or the **official URL**.

---

## APA 7th edition — alphabetical reference list

Awan, M. S. K., Burnap, P., & Rana, O. (2016). Identifying cyber risk hotspots: A framework for measuring temporal variance in computer network risk. *Computers & Security*, *57*, 31–46. https://doi.org/10.1016/j.cose.2015.11.003

Barth, A. (2011). *HTTP state management mechanism* (RFC 6265). RFC Editor. https://doi.org/10.17487/RFC6265

Bootstrap contributors. (n.d.). *Bootstrap 5 documentation*. Retrieved March 22, 2025, from https://getbootstrap.com/docs/5.3/getting-started/introduction/

Bray, T. (Ed.). (2017). *The JavaScript Object Notation (JSON) data interchange format* (RFC 8259). RFC Editor. https://doi.org/10.17487/RFC8259

Chart.js contributors. (n.d.). *Chart.js documentation*. Retrieved March 22, 2025, from https://www.chartjs.org/docs/latest/

Connolly, T. M., & Begg, C. E. (2015). *Database systems: A practical approach to design, implementation, and management* (6th ed.). Pearson. ISBN 9780132943260.

Elmasri, R., & Navathe, S. B. (2016). *Fundamentals of database systems* (7th ed.). Pearson. ISBN 9780133970777.

Fielding, R., Nottingham, M., & Reschke, J. (Eds.). (2022). *HTTP semantics* (RFC 9110). RFC Editor. https://doi.org/10.17487/RFC9110

Garzón, C. A., Brooker, P., Sakarkar, G., & Carranza, S. (2019). Evaluation of collaborative consumption of food delivery services through web mining techniques. *Journal of Retailing and Consumer Services*, *46*, 45–50. https://doi.org/10.1016/j.jretconser.2018.05.002

MITRE. (n.d.). CWE-89: Improper neutralization of special elements used in an SQL command (“SQL injection”). *Common Weakness Enumeration*. Retrieved March 22, 2025, from https://cwe.mitre.org/data/definitions/89.html

Mozilla. (n.d.). *JavaScript reference*. *MDN Web Docs*. Retrieved March 22, 2025, from https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference

National Institute of Standards and Technology. (2017a). *Digital identity guidelines* (NIST Special Publication 800-63-3). U.S. Department of Commerce. https://doi.org/10.6028/NIST.SP.800-63-3

National Institute of Standards and Technology. (2017b). *Digital identity guidelines: Authentication and lifecycle management* (NIST Special Publication 800-63B). U.S. Department of Commerce. https://doi.org/10.6028/nist.sp.800-63b

Oracle Corporation. (n.d.). *MySQL 8.0 reference manual*. Retrieved March 22, 2025, from https://dev.mysql.com/doc/refman/8.0/en/

OWASP Foundation. (2021). *OWASP top ten: 2021*. OWASP. https://owasp.org/Top10/2021/en/

OWASP Foundation. (2023). *OWASP application security verification standard* (Version 4.0.3). OWASP. https://github.com/OWASP/ASVS/releases/tag/v4.0.3

OWASP Foundation. (n.d.-a). *Cross-site request forgery prevention cheat sheet*. *OWASP Cheat Sheet Series*. Retrieved March 22, 2025, from https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html

OWASP Foundation. (n.d.-b). *Password storage cheat sheet*. *OWASP Cheat Sheet Series*. Retrieved March 22, 2025, from https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html

PHP Group. (n.d.). *PHP manual*. Retrieved March 22, 2025, from https://www.php.net/manual/en/

Pressman, R. S., & Maxim, B. R. (2019). *Software engineering: A practitioner’s approach* (9th ed.). McGraw-Hill Education. ISBN 9781259872976.

Rescorla, E. (2018). *The transport layer security (TLS) protocol version 1.3* (RFC 8446). RFC Editor. https://doi.org/10.17487/RFC8446

Silberschatz, A., Korth, H. F., & Sudarshan, S. (2019). *Database system concepts* (7th ed.). McGraw-Hill Education. ISBN 9780078022159.

Sommerville, I. (2016). *Software engineering* (10th ed.). Pearson. ISBN 9780133943030.

Tan, G. W.-H., & Ooi, K.-B. (2018). Gender and age: Do they really moderate mobile tourism shopping behavior? *Telematics and Informatics*, *35*(6), 1617–1642. https://doi.org/10.1016/j.tele.2018.04.009

Thakur, A. (2021). Car rental system. *International Journal for Research in Applied Science and Engineering Technology*, *9*(VII), 402–412. https://doi.org/10.22214/ijraset.2021.36339

World Wide Web Consortium. (2025). *Web content accessibility guidelines (WCAG) 2.1*. W3C Recommendation. Retrieved March 22, 2025, from https://www.w3.org/TR/WCAG21/

---

## Harvard-style (author–date) — compact

- Awan *et al.* (2016) *Computers & Security*, doi:10.1016/j.cose.2015.11.003.  
- Barth (2011) RFC 6265, doi:10.17487/RFC6265.  
- Bray (Ed.) (2017) RFC 8259, doi:10.17487/RFC8259.  
- Connolly & Begg (2015) ISBN 9780132943260.  
- Elmasri & Navathe (2016) ISBN 9780133970777.  
- Fielding *et al.* (Eds.) (2022) RFC 9110, doi:10.17487/RFC9110.  
- Garzón *et al.* (2019) doi:10.1016/j.jretconser.2018.05.002.  
- MITRE (n.d.) CWE-89, https://cwe.mitre.org/data/definitions/89.html (accessed: 22 March 2025).  
- Mozilla (n.d.) MDN JavaScript Reference (accessed: 22 March 2025).  
- NIST (2017a) SP 800-63-3, doi:10.6028/NIST.SP.800-63-3.  
- NIST (2017b) SP 800-63B, doi:10.6028/nist.sp.800-63b.  
- Oracle (n.d.) MySQL 8.0 manual (accessed: 22 March 2025).  
- OWASP (2021) Top Ten 2021, https://owasp.org/Top10/2021/en/  
- OWASP (2023) ASVS 4.0.3, GitHub release URL above.  
- OWASP (n.d.-a, n.d.-b) CSRF & password-storage cheat sheets (accessed: 22 March 2025).  
- PHP Group (n.d.) PHP Manual (accessed: 22 March 2025).  
- Pressman & Maxim (2019) ISBN 9781259872976.  
- Rescorla (2018) RFC 8446, doi:10.17487/RFC8446.  
- Silberschatz *et al.* (2019) ISBN 9780078022159.  
- Sommerville (2016) ISBN 9780133943030.  
- Tan & Ooi (2018) doi:10.1016/j.tele.2018.04.009.  
- Thakur (2021) doi:10.22214/ijraset.2021.36339.  
- W3C (2025) WCAG 2.1 TR (accessed: 22 March 2025).  
- Bootstrap, Chart.js (n.d.) official docs (accessed: 22 March 2025).

---

## IEEE style — numbered list (reorder to match first citation in your text)

[1] I. Sommerville, *Software Engineering*, 10th ed. Boston, MA, USA: Pearson, 2016. ISBN 9780133943030.

[2] T. Connolly and C. Begg, *Database Systems: A Practical Approach to Design, Implementation, and Management*, 6th ed. Pearson, 2015. ISBN 9780132943260.

[3] R. Elmasri and S. Navathe, *Fundamentals of Database Systems*, 7th ed. Pearson, 2016. ISBN 9780133970777.

[4] A. Silberschatz, H. F. Korth, and S. Sudarshan, *Database System Concepts*, 7th ed. New York, NY, USA: McGraw-Hill, 2019. ISBN 9780078022159.

[5] R. S. Pressman and B. R. Maxim, *Software Engineering: A Practitioner’s Approach*, 9th ed. New York, NY, USA: McGraw-Hill, 2019. ISBN 9781259872976.

[6] OWASP Foundation, “OWASP Top Ten: 2021,” 2021. [Online]. Available: https://owasp.org/Top10/2021/en/

[7] National Institute of Standards and Technology, *Digital Identity Guidelines*, NIST Special Publication 800-63-3, 2017. doi: 10.6028/NIST.SP.800-63-3.

[8] National Institute of Standards and Technology, *Digital Identity Guidelines: Authentication and Lifecycle Management*, NIST Special Publication 800-63B, Jun. 2017. doi: 10.6028/nist.sp.800-63b.

[9] R. Fielding, M. Nottingham, and J. Reschke, Eds., “HTTP Semantics,” RFC 9110, Jun. 2022. doi: 10.17487/RFC9110.

[10] A. Barth, “HTTP State Management Mechanism,” RFC 6265, Apr. 2011. doi: 10.17487/RFC6265.

[11] E. Rescorla, “The Transport Layer Security (TLS) Protocol Version 1.3,” RFC 8446, Aug. 2018. doi: 10.17487/RFC8446.

[12] T. Bray, Ed., “The JavaScript Object Notation (JSON) Data Interchange Format,” RFC 8259, Dec. 2017. doi: 10.17487/RFC8259.

[13] MITRE, “CWE-89: Improper Neutralization of Special Elements used in an SQL Command (‘SQL Injection’).” [Online]. Available: https://cwe.mitre.org/data/definitions/89.html

[14] M. S. K. Awan, P. Burnap, and O. Rana, “Identifying cyber risk hotspots: A framework for measuring temporal variance in computer network risk,” *Comput. Secur.*, vol. 57, pp. 31–46, Mar. 2016. doi: 10.1016/j.cose.2015.11.003.

[15] C. A. Garzón *et al.*, “Evaluation of collaborative consumption of food delivery services through web mining techniques,” *J. Retail. Consum. Serv.*, vol. 46, pp. 45–50, Jan. 2019. doi: 10.1016/j.jretconser.2018.05.002.

[16] G. W.-H. Tan and K.-B. Ooi, “Gender and age: Do they really moderate mobile tourism shopping behavior?” *Telematics Inform.*, vol. 35, no. 6, pp. 1617–1642, Sep. 2018. doi: 10.1016/j.tele.2018.04.009.

[17] A. Thakur, “Car rental system,” *Int. J. Res. Appl. Sci. Eng. Technol.*, vol. 9, no. VII, pp. 402–412, Jul. 2021. doi: 10.22214/ijraset.2021.36339.

[18] W3C, “Web Content Accessibility Guidelines (WCAG) 2.1,” W3C Recommendation, 2025. [Online]. Available: https://www.w3.org/TR/WCAG21/

[19] Oracle, “MySQL 8.0 Reference Manual.” [Online]. Available: https://dev.mysql.com/doc/refman/8.0/en/

[20] The PHP Group, “PHP Manual.” [Online]. Available: https://www.php.net/manual/en/

[21] Mozilla, “JavaScript reference,” *MDN Web Docs*. [Online]. Available: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference

[22] “Bootstrap 5 documentation,” Bootstrap contributors. [Online]. Available: https://getbootstrap.com/docs/5.3/getting-started/introduction/

[23] “Chart.js documentation,” Chart.js contributors. [Online]. Available: https://www.chartjs.org/docs/latest/

[24] OWASP Foundation, “OWASP Application Security Verification Standard 4.0.3,” 2023. [Online]. Available: https://github.com/OWASP/ASVS/releases/tag/v4.0.3

[25] OWASP Foundation, “Cross-site request forgery prevention cheat sheet,” *OWASP Cheat Sheet Series*. [Online]. Available: https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html

[26] OWASP Foundation, “Password storage cheat sheet,” *OWASP Cheat Sheet Series*. [Online]. Available: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html

---

## How to verify

| Evidence type | Where to check |
|---------------|----------------|
| **DOI** | https://doi.org/\<DOI\> |
| **ISBN** | Publisher or library catalogue |
| **RFC** | https://www.rfc-editor.org/ (same document as DOI 10.17487/…) |
| **W3C / OWASP / MITRE / vendor docs** | Official URLs above; note **access date** for web pages |

Update all **Retrieved / accessed** dates to the last day you opened each page before final submission.

---

## Suggested in-text use (APA)

- Software process / requirements: Sommerville (2016); Pressman & Maxim (2019).  
- Relational design & SQL: Connolly & Begg (2015); Elmasri & Navathe (2016); Silberschatz *et al.* (2019).  
- HTTP, cookies, TLS, JSON: Fielding *et al.* (2022); Barth (2011); Rescorla (2018); Bray (2017).  
- Threats & secure coding: OWASP (2021); MITRE (n.d.); OWASP cheat sheets; Awan *et al.* (2016).  
- Authentication & passwords: NIST SP 800-63-3 and 800-63B (2017); OWASP password storage cheat sheet.  
- CSRF: OWASP CSRF cheat sheet.  
- Online booking / mobile commerce context: Tan & Ooi (2018); Garzón *et al.* (2019).  
- Car-rental web systems: Thakur (2021).  
- Stack documentation: Oracle (n.d.); PHP Group (n.d.); Mozilla (n.d.); Bootstrap; Chart.js.  
- Accessibility: W3C (2025).
